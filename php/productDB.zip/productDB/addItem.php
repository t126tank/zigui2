<?php
    header('Content-Type:text/html;charset=utf-8');
    include('sessionCheck.php');

    $type = trim($_GET['type']);

    if ($type == "product")
    {
        $name = trim($_POST['prd_name']);
        $pic = trim($_POST['prd_pic']);
        $url = "<a href=" . trim($_POST['prd_url']) . ">product link</a>";
        $ja_detail = trim($_POST['prd_ja_detail']);
        $cn_detail = trim($_POST['prd_cn_detail']);
        $cat_id = trim($_POST['prd_cat_id'])+0;
        $note = trim($_POST['prd_note']);

        $shops_all = ";";
        // save shops ID as : 1;3;4;
        foreach ($_POST['prd_shops'] as $value)
        {
            $shops_all = $shops_all . $value . ";"; 
        }

        if ($name == "" || $cat_id == 0)
        {
            echo "Please input necessary information！";
            exit();
        }
        else
        {
            $sql = "insert into product ";
            $sql = $sql . " (prd_name,prd_pic,prd_url,prd_ja_detail,prd_cn_detail,prd_cat_id,prd_shops,prd_note) ";
            $sql = $sql . " values ('" . $name . "','" . $pic . "','" . $url . "','" . $ja_detail . "','" . $cn_detail . "','" . $cat_id . "','" . $shops_all . "','" . $note . "')" ;
        }
    }
    else if ($type == "shop")
    {
        $name = trim($_POST['shop_name']);
        $url = "<a href=" . trim($_POST['shop_url']) . ">shop link</a>";
        $city_id = trim($_POST['shop_city_id'])+0;

        if ($name == "" || $city_id == 0)
        {
            echo "Please input necessary information！";
            exit();
        }
        else
        {
            $sql = "insert into shop ";
            $sql = $sql . " (shop_name,shop_url,shop_city_id) ";
            $sql = $sql . " values ('" . $name . "','" . $url . "','" . $city_id . "')" ;
        }
    }
    else // catalogue
    {
        $name = trim($_POST['cat_name']);

        if ($name == "")
        {
            echo "Please input necessary information！";
            exit();
        }
        else
        {
            $sql = "insert into catalogue ";
            $sql = $sql . " (cat_name) ";
            $sql = $sql . " values ('" . $name . "')" ;
        }
    }

    $db = sqlite_open(".productDB.sqlite");
//        $sql = "insert into product (movie,url,content,time) values ( '$movie','$url','$content','$now')";
    $result = sqlite_query($db, $sql);

    if ($result)
    {
        echo "Add " . $type . " successful!";
        echo "Click<a href='manageInfo.html'> HERE </a> to add more";
    }
    else
    {
        echo "Add " . $type . " failed!";
    }
?>
