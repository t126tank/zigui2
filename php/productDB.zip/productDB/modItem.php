<?php
    header('Content-Type:text/html;charset=utf-8');
    include('sessionCheck.php');

    $type = trim($_GET['type']);

    if ($type == "product")
    {
        $id = trim($_POST['prd_id']);
        $name = trim($_POST['prd_name']);
        $pic = trim($_POST['prd_pic']);
        $url = "<a href=" . trim($_POST['prd_url']) . ">product link</a>";
        $ja_detail = trim($_POST['prd_ja_detail']);
        $cn_detail = trim($_POST['prd_cn_detail']);
        $cat_id = trim($_POST['prd_cat_id']);
        $note = trim($_POST['prd_note']);

        $shops_all = ";";
        // save shops ID as : 1;3;4;
        foreach ($_POST['prd_shops'] as $value)
        {
            $shops_all = $shops_all . $value . ";"; 
        }

        if ($id == "" || $name == "" || $cat_id == "")
        {
            echo "Please input necessary information！";
            exit();
        }
        else
        {
            $sql = "update product ";
            $sql = $sql . "set prd_id = '" . $id . "', prd_name = '" . $name . "', prd_pic = '" . $pic . "', prd_url = '" . $url . "', prd_ja_detail = '" . $ja_detail . "', prd_cn_detail = '" . $cn_detail . "', prd_cat_id = '" . $cat_id . "', prd_shops = '" . $shops_all . "', prd_note = '" . $note . "'";
            $sql = $sql . " where prd_id = '" . $id . "'";
        }
    }
    else if ($type == "shop")
    {
        $id = trim($_POST['shop_id']);
        $name = trim($_POST['shop_name']);
        $url = "<a href=" . trim($_POST['shop_url']) . ">shop link</a>";
        $city_id = trim($_POST['shop_city_id'])+0;

        if ($id == "" || $name == "" || $city_id == 0)
        {
            echo "Please input necessary information！";
            exit();
        }
        else
        {
            $sql = "update shop ";
            $sql = $sql . "set shop_id = '" . $id . "', shop_name = '" . $name . "', shop_url = '" . $url . "', shop_city_id = '" . $city_id . "'";
            $sql = $sql . " where shop_id = '" . $id . "'";
        }
    }
    else // catalogue
    {
        $id = trim($_POST['cat_id']);
        $name = trim($_POST['cat_name']);

        if ($id == ""  || $name == "")
        {
            echo "Please input necessary information！";
            exit();
        }
        else
        {
            $sql = "update catalogue ";
            $sql = $sql . "set cat_id = '" . $id . "', cat_name = '" . $name . "'";
            $sql = $sql . " where cat_id = '" . $id . "'";
        }
    }

    $db = sqlite_open(".productDB.sqlite");
//        $sql = "insert into product (movie,url,content,time) values ( '$movie','$url','$content','$now')";
    $result = sqlite_query($db, $sql);

    if ($result)
    {
        echo "Update " . $type . " successful!";
        echo "Click<a href='manageInfo.html'> HERE </a> to update more";
    }
    else
    {
        echo "Update " . $type . " failed!";
    }
?>
