<?php
session_start();
if ($_SESSION['user_name'] != "admin")
{
  print("Error: User not login!\n"); 
  echo "<a href=index.html>entry</a>" ;
  exit;
}
?>