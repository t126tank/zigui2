<?php
session_start();

if (!empty($_POST['Submit'])) {
 $user_name = $_POST['user_name'];
 $user_pwd = $_POST['user_pwd'];
 $yzm  = $_POST['yzm'];
 
 if(empty($user_name) || empty($user_pwd)){
  print(" NULL not allowed !");
 }
 
 if( $user_name=="admin" && $user_pwd=="admin" && $yzm=="") {
  $_SESSION['admin'] = 'admin';
  
  $_SESSION['user_name'] = "admin";
  echo "<a href=main.php> Check OK</a>" ;
 } else {
  print("User not exist!\n");  
  echo "<a href=index.html>login</a>" ;
  $_SESSION['user_name'] = "";
 }
} else {
  echo "<a href=index.html>login</a>" ;
  $_SESSION['user_name'] = "";
}

?>
