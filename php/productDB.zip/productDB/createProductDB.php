<?php
header('Content-Type:text/html;charset=utf-8');
include('sessionCheck.php');

function readf($file)
{
    if(function_exists('file_get_contents'))
    {
        $content=file_get_contents($file);
    }
    else
    {
        $fp=fopen($file,'r');
        while(!feof($fp))
        {
            $content=fgets($fp,1024);
        }
        fclose($fp);
    }
    return $content;
}

// Init DB
$link=sqlite_open(".productDB.sqlite");
echo $sql;
if ($link)
{
    if (is_file('katokunou-product.sql') && is_readable('katokunou-product.sql'))
    {

        $sql=readf('katokunou-product.sql');
        $sql=explode(';', $sql);
        $error='';
        foreach ($sql as $k=>$v)
        {
            if (@sqlite_query($v,$link))
            {
                if (!sqlite_last_error($link))
                {

                }
                else
                {
                    $error = sqlite_error_string(sqlite_last_error($link));
                }
            }
        }
        echo "Create DB finished! <br>";
        echo $error;
    }
}
else
{
    echo "Failed to open DB! <br>";
}
echo "<a href='./main.php'> Back </a><br>";
echo "<a href='http://katokunou.com'> Katokunou Inc. </a><br>";

?>
