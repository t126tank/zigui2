<?php
    $db = sqlite_open(".productDB.sqlite"); // connect DB
    $sql = "select * from product ";
    $query = sqlite_query($db, $sql); // select all from table
?>

<html>
<head>
<title> List all products</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>

<body>
<table width="100%" border="1">

<?php
    while ($res = sqlite_fetch_array($query))
    {
        // show the data
        echo "<tr><td> Product ID: ";
        echo $res['prd_id'];
        echo "</td>";
        echo "<td> Product name: ";
        echo $res['prd_name'];
        echo "</td>";
        echo "<td>";
        echo "<a href='readProductDetails.php?prd_id=" . $res['prd_id'] . "'> Detail </a>";
        echo "</td></tr>";
    }
?>

</table>

<a href='./main.php'> Back </a><br>
<a href='http://katokunou.com'> Katokunou Inc. </a><br>

</body>
</html>
