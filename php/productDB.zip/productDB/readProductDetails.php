<?php
    header('Content-Type:text/html;charset=utf-8');
    include('sessionCheck.php');

    $prd_id = trim($_GET['prd_id']);

    $db = sqlite_open(".productDB.sqlite"); // connect DB

    $prd_sql = "select * from product where lower(prd_id) = '$prd_id'";
    $prd_query = sqlite_query($db, $prd_sql); // select product

// show product details -->
    while ($prd_res = sqlite_fetch_array($prd_query))
    {

        $cat_sql = "select * from catalogue where lower(cat_id) = '$prd_res[prd_cat_id]'";
        $cat_query = sqlite_query($db, $cat_sql); // select catalogue
        $cat_res = sqlite_fetch_array($cat_query);

//        $shops_id_list = str_replace(";", " ", $prd_res[prd_shops]);
//        $shop_sql = "select * from shop where lower(shop_id) in '$shops_id_list'";
        $shops_id_list = $prd_res[prd_shops];
        $shop_sql = "select * from shop ";
        $shop_query = sqlite_query($db, $shop_sql); // select catalogue
        while ($shop_res = sqlite_fetch_array($shop_query))
        {
            if (strstr($shops_id_list, ";" . $shop_res[shop_id] . ";"))
            {
                $shops_name_list = $shops_name_list . $shop_res[shop_name] . ";";
            }
        }

echo <<<EOF
    <table width="48%" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
            <td width="36%" height="38"><div align="right">Product ID：</div></td>
            <td width="64%"> {$prd_res[prd_id]} </td>
        </tr>
        <tr>
            <td width="36%" height="38"><div align="right">Product name：</div></td>
            <td width="64%"> {$prd_res[prd_name]} </td>
        </tr>
        <tr>
            <td width="36%" height="38"><div align="right">Product picture link：</div></td>
            <td width="64%"> <a href='./prd_img/{$prd_res[prd_pic]}'> Picture </a> </td>
        </tr>
        <tr>
            <td width="36%" height="38"><div align="right">Product URL：</div></td>
            <td width="64%"> {$prd_res[prd_url]} </td>
        </tr>
        <tr>
            <td height="33"><div align="right">Japanese Description：</div></td>
            <td width="64%"> {$prd_res[prd_ja_detail]} </td>
        </tr>
        <tr>
            <td height="33"><div align="right">Chinese Description：</div></td>
            <td width="64%"> {$prd_res[prd_cn_detail]} </td>
        </tr>
        <tr>
            <td width="36%" height="38"><div align="right">Catalogue：</div></td>
            <td width="64%"> {$cat_res[cat_name]} </td>
        </tr>
        <tr>
            <td width="36%" height="38"><div align="right">Sale Shops：</div></td>
            <td width="64%"> {$shops_name_list} </td>
        </tr>
        <tr>
            <td height="33"><div align="right">Product Note：</div></td>
            <td width="64%"> {$prd_res[prd_note]} </td>
        </tr>
EOF;
    }

    echo "<a href='./main.php'> Back </a><br>";
    echo "<a href='http://katokunou.com'> Katokunou Inc. </a><br>";
?>
