<?php

    header('Content-Type:text/html;charset=utf-8');
    include('sessionCheck.php');

    $type = trim($_GET['type']);

    if ($type == "")
    {
        echo "Wrong manage information！<br>";
        echo "<a href='./main.php'> Back </a><br>";
        echo "<a href='http://katokunou.com'> Katokunou Inc. </a><br>";

        exit();
    }

    $db = sqlite_open(".productDB.sqlite"); // connect DB

    $prd_sql = "select * from product ";
    $prd_query = sqlite_query($db, $prd_sql); // select all from table

    $shop_sql = "select * from shop ";
    $shop_query = sqlite_query($db, $shop_sql); // select all from table

    $cat_sql = "select * from catalogue ";
    $cat_query = sqlite_query($db, $cat_sql); // select all from table
?>

<html>
<head>
<title> List all products</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>

<body>
<table width="100%" border="1">

<?php
    if ($type == "product")
    {
        while ($prd_res = sqlite_fetch_array($prd_query))
        {
            // show the data
            echo "<tr><td> Product ID: ";
            echo $prd_res['prd_id'];
            echo "</td>";
            echo "<td> Product name: ";
            echo $prd_res['prd_name'];
            echo "</td>";
            echo "<td>";
            echo "<a href='readProductDetails.php?prd_id=" . $prd_res['prd_id'] . "'> Detail </a>";
            echo "</td></tr>";
        }
    }
    else if ($type == "shop")
    {
        while ($shop_res = sqlite_fetch_array($shop_query))
        {
            // show the data
            echo "<tr><td> Shop ID: ";
            echo $shop_res['shop_id'];
            echo "</td>";
            echo "<td> Shop name: ";
            echo $shop_res['shop_name'];
            echo "</td></tr>";
        }
    }
    else // catalogue
    {
        while ($cat_res = sqlite_fetch_array($cat_query))
        {
            // show the data
            echo "<tr><td> Catalogue ID: ";
            echo $cat_res['cat_id'];
            echo "</td>";
            echo "<td> Catalogue name: ";
            echo $cat_res['cat_name'];
            echo "</td></tr>";
        }
    }
?>

</table>

<a href='./main.php'> Back </a><br>
<a href='http://katokunou.com'> Katokunou Inc. </a><br>

</body>
</html>
