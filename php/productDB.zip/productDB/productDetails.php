<form name="form1" method="post" action="addProduct.php">
    <table width="48%" border="0" align="center" cellpadding="0" cellspacing="0">

        <tr>

                <td width="36%" height="38"><div align="right">movie name：</div></td>

                <td width="64%"> <input type="text" name="movie"> </td>

        </tr>

        <tr>

                <td height="39"><div align="right">url name：</div></td>

                <td><input type="text" name="url"></td>

        </tr>

        <tr>

                <td height="33"><div align="right">content name：</div></td>

                <td><textarea name="content"></textarea></td>

        </tr>

        <tr>

                <td height="53" colspan="2"><div align="center">

                <input type="submit" name="Submit" value="Submit">&nbsp;&nbsp;&nbsp;&nbsp;

                <input type="reset"  value="Reset">

                </div></td>

        </tr>

    </table>

</form>
