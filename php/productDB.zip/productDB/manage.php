<?php
    header('Content-Type:text/html;charset=utf-8');
    include('sessionCheck.php');

    $type = trim($_GET['type']);

    if ($type == "")
    {
        echo "Wrong manage information！<br>";
        echo "<a href='./main.php'> Back </a><br>";
        echo "<a href='http://katokunou.com'> Katokunou Inc. </a><br>";

        exit();
    }

    echo "<a href='detailItem.php?type=" . $type . "&todo=add'> Add " . $type . " </a><br>";
    echo "<a href='detailItem.php?type=" . $type . "&todo=mod'> Modify " . $type . " </a><br>";
    echo "<a href='detailItem.php?type=" . $type . "&todo=del'> Delete " . $type . " </a><br>";

    echo "<a href='./main.php'> Back </a><br>";
    echo "<a href='http://katokunou.com'> Katokunou Inc. </a><br>";
?>
