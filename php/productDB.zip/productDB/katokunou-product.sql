CREATE TABLE 'shop' ( 'shop_id' INTEGER PRIMARY KEY , 'shop_name' VARCHAR (500), 'shop_url' VARCHAR (500), 'shop_city_id' INTEGER );
CREATE TABLE 'product' ( 'prd_id' INTEGER PRIMARY KEY, 'prd_name' VARCHAR(50), 'prd_pic' VARCHAR(50), 'prd_url' VARCHAR(500), 'prd_ja_detail' VARCHAR(1000), 'prd_cn_detail' VARCHAR(1000), 'prd_cat_id' INTEGER, 'prd_shops' VARCHAR(1000), 'prd_note' VARCHAR(1000) );
CREATE TABLE 'catalogue' ( 'cat_id' INTEGER PRIMARY KEY , 'cat_name' VARCHAR (50) );
CREATE TABLE 'psrelation' ( 'ps_id' INTEGER PRIMARY KEY , 'ps_prd_id' INTEGER , 'ps_shop_id' INTEGER );
CREATE TABLE 'city' ( 'city_id' INTEGER PRIMARY KEY , 'city_name' VARCHAR (50) );


INSERT INTO 'shop' VALUES ('1', '新寨子旗舰店', '<a href=http://dalian.katokunou.com>shop link</a>', '3');
INSERT INTO 'shop' VALUES ('2', '北京淘宝', '<a href=http://beijing.katokunou.com>shop link</a>', '1');
INSERT INTO 'shop' VALUES ('3', '上海淘宝', '<a href=http://shanghai.katokunou.co>shoplink</a>m', '2');

INSERT INTO 'product' VALUES ('1', '商品1', 'ktn.png', '<a href=http://www.google.com>product link</a>', '', '', '7', '', '');
INSERT INTO 'product' VALUES ('2', '商品2', 'ktn.png', '<a href=http://www.google.com>product link</a>', '', '', '3', '', '');
INSERT INTO 'product' VALUES ('3', '商品3', 'ktn.png', '<a href=http://www.google.com>product link</a>', '', '', '5', '', '');
INSERT INTO 'product' VALUES ('4', '商品4', 'ktn.png', '<a href=http://www.google.com>product link</a>', '', '', '4', '', '');
INSERT INTO 'product' VALUES ('5', '商品5', 'ktn.png', '<a href=http://www.google.com>product link</a>', '', '', '1', '', '');

INSERT INTO 'catalogue' VALUES ('1', '健康食品');
INSERT INTO 'catalogue' VALUES ('2', '美容养颜');
INSERT INTO 'catalogue' VALUES ('3', '延年益寿');
INSERT INTO 'catalogue' VALUES ('4', '补脑益智');
INSERT INTO 'catalogue' VALUES ('5', '婴幼儿辅食');
INSERT INTO 'catalogue' VALUES ('6', '孕妇安养胎');
INSERT INTO 'catalogue' VALUES ('7', '其他');

INSERT INTO 'psrelation' VALUES ('1', '1', '3');
INSERT INTO 'psrelation' VALUES ('2', '2', '3');
INSERT INTO 'psrelation' VALUES ('3', '3', '2');

INSERT INTO 'city' VALUES ('1', '北京');
INSERT INTO 'city' VALUES ('2', '上海');
INSERT INTO 'city' VALUES ('3', '大连');
INSERT INTO 'city' VALUES ('4', '湖北');
INSERT INTO 'city' VALUES ('5', '天津');
INSERT INTO 'city' VALUES ('6', '内蒙古');
INSERT INTO 'city' VALUES ('7', '山东');
INSERT INTO 'city' VALUES ('8', '新疆');
INSERT INTO 'city' VALUES ('9', '香港');
INSERT INTO 'city' VALUES ('10', '台湾');
INSERT INTO 'city' VALUES ('11', '澳门');
INSERT INTO 'city' VALUES ('12', '其他');


