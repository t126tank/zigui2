<?php
session_start();
if ($_SESSION['user_name'] == "admin")
{
echo <<<EOF
<html>
<a href="./listItem.php?type=product"> Product </a>
<br>
<a href="./listItem.php?type=shop"> Shop </a>
<br>
<a href="./listItem.php?type=catalogue"> Catalogue </a>
<br>
<a href="./main.php"> Back </a>
<br>
<a href="http://katokunou.com"> Katokunou Inc. </a>
<br>
</html>
EOF;
} else {
  print("Error: User not login!\n"); 
  echo "<a href=main.php>entry</a>" ;
}
?>
