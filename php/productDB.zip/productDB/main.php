<?php
session_start();
if ($_SESSION['user_name'] == "admin")
{
echo <<<EOF
<html>
<a href="./createProductDB.php"> Create DB </a>
<br>
<a href="./manageInfo.php"> Manage Information </a>
<br>
<a href="./listInfo.php"> List Data </a>
<br>
<a href="./queryProduct.php"> Query Product Information </a>
<br>
<a href="http://katokunou.com"> Katokunou Inc. </a>
<br>
</html>
EOF;
} else {
  print("Error: User not login!\n"); 
  echo "<a href=index.html>entry</a>" ;
}
?>
