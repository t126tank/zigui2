<html>

<form>
</form>

<br>
<a href="./queryProduct.html"> Query Product Information </a>
<br>
<a href="http://katokunou.com"> Katokunou Inc. </a>
<br>
</html>
