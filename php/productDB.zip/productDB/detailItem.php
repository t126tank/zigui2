<?php
    header('Content-Type:text/html;charset=utf-8');
    include('sessionCheck.php');

    $type = trim($_GET['type']);
    $todo = trim($_GET['todo']);

    if ($type == "" || $todo =="")
    {
        echo "Wrong " . $type . " information！<br>";
        echo "<a href='./main.php'> Back </a><br>";
        echo "<a href='http://katokunou.com'> Katokunou Inc. </a><br>";

        exit();
    }

    $db = sqlite_open(".productDB.sqlite"); // connect DB

    $cat_sql = "select * from catalogue ";
    $cat_query = sqlite_query($db, $cat_sql); // select all from catalogue

    $shop_sql = "select * from shop ";
    $shop_query = sqlite_query($db, $shop_sql); // select all from shop

    $city_sql = "select * from city ";
    $city_query = sqlite_query($db, $city_sql); // select all from city

    if ($todo == "add")
    {
        if ($type == "product")
        {
// Add product -->
echo <<<EOF
<form name="form_{$todo}" method="post" action="addItem.php?type={$type}">
    <table width="48%" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
            <td width="36%" height="38"><div align="right">Product name：</div></td>
            <td width="64%"> <input type="text" name="prd_name"> </td>
        </tr>
        <tr>
            <td width="36%" height="38"><div align="right">Product picture name：</div></td>
            <td width="64%"> <input type="text" name="prd_pic"> </td>
        </tr>
        <tr>
            <td width="36%" height="38"><div align="right">Product URL (Need "http://~")：</div></td>
            <td width="64%"> <input type="text" name="prd_url"> </td>
        </tr>
        <tr>
            <td height="33"><div align="right">Japanese Description：</div></td>
            <td><textarea name="prd_ja_detail" rows='10' cols='40'></textarea></td>
        </tr>
        <tr>
            <td height="33"><div align="right">Chinese Description：</div></td>
            <td><textarea name="prd_cn_detail" rows='10' cols='40'></textarea></td>
        </tr>
        <tr>
            <td width="36%" height="38"><div align="right">Catalogue：</div></td>
            <td width="64%">
                <select name="prd_cat_id">
EOF;

            while ($cat_res = sqlite_fetch_array($cat_query))
            {
                echo "<option value='" . $cat_res['cat_id'] . "'>" . $cat_res['cat_name'] . "</option>";
            }

echo <<<EOF
                </select>
            </td>
        </tr>
        <tr>
            <td width="36%" height="38"><div align="right">Sale Shops：</div></td>
            <td width="64%">
EOF;

            while ($shop_res = sqlite_fetch_array($shop_query))
            {
                echo $shop_res[shop_name] . ": ";
                echo "<input type='checkbox' name='prd_shops[ ]' value='" . $shop_res[shop_id] . "' checked='checked'><br>";
            }

echo <<<EOF
            </td>
        </tr>
        <tr>
            <td height="33"><div align="right">Product Note：</div></td>
            <td><textarea name="prd_note" rows='10' cols='40'></textarea></td>
        </tr>
        <tr>
            <td height="53" colspan="2"><div align="center">
                <input type="submit" name="Submit" value="Submit">&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="reset"  value="Reset">
            </div></td>
        </tr>
    </table>
</form>
EOF;
// <-- Add product
        }
        else if ($type == "shop")
        {
// Add shop -->
echo <<<EOF
<form name="form_{$todo}" method="post" action="addItem.php?type={$type}">
    <table width="48%" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
            <td width="36%" height="38"><div align="right">Shop name：</div></td>
            <td width="64%"> <input type="text" name="shop_name"> </td>
        </tr>
        <tr>
            <td width="36%" height="38"><div align="right">Shop URL (Need "http://~")：</div></td>
            <td width="64%"> <input type="text" name="shop_url"> </td>
        </tr>
        <tr>
            <td width="36%" height="38"><div align="right">Shop location：</div></td>
            <td width="64%">
                <select name="shop_city_id">
EOF;

            while ($city_res = sqlite_fetch_array($city_query))
            {
                echo "<option value='" . $city_res['city_id'] . "'>" . $city_res['city_name'] . "</option>";
            }

echo <<<EOF
                </select>
            </td>
        </tr>
        <tr>
            <td height="53" colspan="2"><div align="center">
                <input type="submit" name="Submit" value="Submit">&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="reset"  value="Reset">
            </div></td>
        </tr>
    </table>
</form>
EOF;
// <-- Add shop
        }
        else // "catalogue"
        {
// Add catalogue -->
echo <<<EOF
<form name="form_{$todo}" method="post" action="addItem.php?type={$type}">
    <table width="48%" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
            <td width="36%" height="38"><div align="right">Catalogue name：</div></td>
            <td width="64%"> <input type="text" name="cat_name"> </td>
        </tr>
        <tr>
            <td height="53" colspan="2"><div align="center">
                <input type="submit" name="Submit" value="Submit">&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="reset"  value="Reset">
            </div></td>
        </tr>
    </table>
</form>
EOF;
// <-- Add catalogue
        }
    }
    else if ($todo == "mod")
    {
        if ($type == "product")
        {
// modify product -->
echo <<<EOF
<form name="form_{$todo}" method="post" action="modItem.php?type={$type}">
    <table width="48%" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
            <td width="36%" height="38"><div align="right">Product ID：</div></td>
            <td width="64%"> <input type="text" name="prd_id"> </td>
        </tr>
        <tr>
            <td width="36%" height="38"><div align="right">Product name：</div></td>
            <td width="64%"> <input type="text" name="prd_name"> </td>
        </tr>
        <tr>
            <td width="36%" height="38"><div align="right">Product picture name：</div></td>
            <td width="64%"> <input type="text" name="prd_pic"> </td>
        </tr>
        <tr>
            <td width="36%" height="38"><div align="right">Product URL(Need "http://~")：</div></td>
            <td width="64%"> <input type="text" name="prd_url"> </td>
        </tr>
        <tr>
            <td height="33"><div align="right">Japanese Description：</div></td>
            <td><textarea name="prd_ja_detail" rows='10' cols='40'></textarea></td>
        </tr>
        <tr>
            <td height="33"><div align="right">Chinese Description：</div></td>
            <td><textarea name="prd_cn_detail" rows='10' cols='40'></textarea></td>
        </tr>
        <tr>
            <td width="36%" height="38"><div align="right">Catalogue：</div></td>
            <td width="64%">
                <select name="prd_cat_id">
EOF;

            while ($cat_res = sqlite_fetch_array($cat_query))
            {
                echo "<option value='" . $cat_res['cat_id'] . "'>" . $cat_res['cat_name'] . "</option>";
            }

echo <<<EOF
                </select>
            </td>
        </tr>
        <tr>
            <td width="36%" height="38"><div align="right">Sale Shops：</div></td>
            <td width="64%">
EOF;

            while ($shop_res = sqlite_fetch_array($shop_query))
            {
                echo $shop_res[shop_name] . ": ";
                echo "<input type='checkbox' name='prd_shops[ ]' value='" . $shop_res[shop_id] . "' checked='checked'><br>";
            }

echo <<<EOF
            </td>
        </tr>
        <tr>
            <td height="33"><div align="right">Product Note：</div></td>
            <td><textarea name="prd_note" rows='10' cols='40'></textarea></td>
        </tr>
        <tr>
            <td height="53" colspan="2"><div align="center">
                <input type="submit" name="Submit" value="Submit">&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="reset"  value="Reset">
            </div></td>
        </tr>
    </table>
</form>
EOF;
// <-- modify product
        }
        else if ($type == "shop")
        {
// Modify shop -->
echo <<<EOF
<form name="form_{$todo}" method="post" action="modItem.php?type={$type}">
    <table width="48%" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
            <td width="36%" height="38"><div align="right">Shop ID：</div></td>
            <td width="64%"> <input type="text" name="shop_id"> </td>
        </tr>
        <tr>
            <td width="36%" height="38"><div align="right">Shop name：</div></td>
            <td width="64%"> <input type="text" name="shop_name"> </td>
        </tr>
        <tr>
            <td width="36%" height="38"><div align="right">Shop URL (Need "http://~")：</div></td>
            <td width="64%"> <input type="text" name="shop_url"> </td>
        </tr>
        <tr>
            <td width="36%" height="38"><div align="right">Shop location：</div></td>
            <td width="64%">
                <select name="shop_city_id">
EOF;

            while ($city_res = sqlite_fetch_array($city_query))
            {
                echo "<option value='" . $city_res['city_id'] . "'>" . $city_res['city_name'] . "</option>";
            }

echo <<<EOF
                </select>
            </td>
        </tr>
        <tr>
            <td height="53" colspan="2"><div align="center">
                <input type="submit" name="Submit" value="Submit">&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="reset"  value="Reset">
            </div></td>
        </tr>
    </table>
</form>
EOF;
// <-- Modify shop
        }
        else // "catalogue"
        {
// Modify catalogue -->
echo <<<EOF
<form name="form_{$todo}" method="post" action="modItem.php?type={$type}">
    <table width="48%" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
            <td width="36%" height="38"><div align="right">Catalogue ID：</div></td>
            <td width="64%"> <input type="text" name="cat_id"> </td>
        </tr>
        <tr>
            <td width="36%" height="38"><div align="right">Catalogue Name：</div></td>
            <td width="64%"> <input type="text" name="cat_name"> </td>
        </tr>
        <tr>
            <td height="53" colspan="2"><div align="center">
                <input type="submit" name="Submit" value="Submit">&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="reset"  value="Reset">
            </div></td>
        </tr>
    </table>
</form>
EOF;
// <-- Modify Catagolue
        }
    }
    else  // del
    {
        if ($type == "product")
        {
// delete product -->
echo <<<EOF
<form name="form_{$todo}" method="post" action="delItem.php?type={$type}">
    <table width="48%" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
            <td width="36%" height="38"><div align="right">Product ID：</div></td>
            <td width="64%"> <input type="text" name="prd_id"> </td>
        </tr>
        <tr>
            <td height="53" colspan="2"><div align="center">
                <input type="submit" name="Submit" value="Submit">&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="reset"  value="Reset">
            </div></td>
        </tr>
    </table>
</form>
EOF;
// <-- delete product
        }
        else if ($type == "shop")
        {
// delete shop -->
echo <<<EOF
<form name="form_{$todo}" method="post" action="delItem.php?type={$type}">
    <table width="48%" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
            <td width="36%" height="38"><div align="right">Shop ID：</div></td>
            <td width="64%"> <input type="text" name="shop_id"> </td>
        </tr>
        <tr>
            <td height="53" colspan="2"><div align="center">
                <input type="submit" name="Submit" value="Submit">&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="reset"  value="Reset">
            </div></td>
        </tr>
    </table>
</form>
EOF;
// <-- delete shop
        }
        else // "catalogue"
        {
// delete catalogue -->
echo <<<EOF
<form name="form_{$todo}" method="post" action="delItem.php?type={$type}">
    <table width="48%" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
            <td width="36%" height="38"><div align="right">Catalogue ID：</div></td>
            <td width="64%"> <input type="text" name="cat_id"> </td>
        </tr>
        <tr>
            <td height="53" colspan="2"><div align="center">
                <input type="submit" name="Submit" value="Submit">&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="reset"  value="Reset">
            </div></td>
        </tr>
    </table>
</form>
EOF;
// <-- delete catalogue
        }
    }

    echo "<a href='./main.php'> Back </a><br>";
    echo "<a href='http://katokunou.com'> Katokunou Inc. </a><br>";

?>
