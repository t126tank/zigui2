<?php
    header('Content-Type:text/html;charset=utf-8');
    include('sessionCheck.php');

    $type = trim($_GET['type']);

    if ($type == "product")
    {
        $id = trim($_POST['prd_id']);

        if ($id == "")
        {
            echo "Please input necessary information！";
            exit();
        }
        else
        {
            $sql = "delete from product ";
            $sql = $sql . " where prd_id = '" . $id . "'";
        }
    }
    else if ($type == "shop")
    {
        $id = trim($_POST['shop_id']);

        if ($id == "")
        {
            echo "Please input necessary information！";
            exit();
        }
        else
        {
            $sql = "delete from shop ";
            $sql = $sql . " where shop_id = '" . $id . "'";
        }
    }
    else // catalogue
    {
        $id = trim($_POST['cat_id']);

        if ($id == "")
        {
            echo "Please input necessary information！";
            exit();
        }
        else
        {
            $sql = "delete from catalogue ";
            $sql = $sql . " where cat_id = '" . $id . "'";
        }
    }

    $db = sqlite_open(".productDB.sqlite");
//        $sql = "insert into product (movie,url,content,time) values ( '$movie','$url','$content','$now')";
    $result = sqlite_query($db, $sql);

    if ($result)
    {
        echo "Delete " . $type . " successful!";
        echo "Click<a href='manageInfo.html'> HERE </a> to delete more";
    }
    else
    {
        echo "Delete " . $type . " failed!";
    }
?>
